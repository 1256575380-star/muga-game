const test=require('node:test'),assert=require('node:assert/strict'),S=require('../dist/storage.js'),E=require('../dist/engine.js');
const cp=x=>JSON.parse(JSON.stringify(x));
function memory(){const map=new Map();return {getItem:k=>map.get(k)||null,setItem:(k,v)=>map.set(k,v),map};}
function idb(initial=[],{failRead=false,failWrite=false,hold=false}={}){
  const rows=new Map(initial.map(r=>[r.id,cp(r)]));
  return {open(){
    const req={};
    queueMicrotask(()=>{
      req.result={objectStoreNames:{contains:()=>true},close(){},transaction(){
        let cancelled=false;
        const tx={abort(){cancelled=true;tx.onabort?.();},objectStore(){return {
          getAll(){const r={};queueMicrotask(()=>{if(failRead)r.onerror?.();else{r.result=[...rows.values()].map(cp);r.onsuccess?.();}});return r;},
          put(record){if(hold)return;queueMicrotask(()=>{if(cancelled)return;if(failWrite)tx.onerror?.();else{rows.set(record.id,cp(record));tx.oncomplete?.();}});}
        };}};
        return tx;
      }};
      req.onsuccess?.();
    });
    return req;
  }};
}
const make=()=>E.createGame({seed:'persistence'}),create=(local,db,opts={})=>S.create({local,indexedDB:db,validate:E.validateSave,timeout:30,...opts});
test('fresh page resumes the newest legacy save, preserving the exact game and RNG',async()=>{const local=memory(),a=make(),b=make();E.next(b);const db=idb([{id:1,state:a,updated:100},{id:2,state:b,updated:200}]);const store=create(local,db);await store.init();assert.equal(store.resume().id,2);assert.deepEqual(store.resume().state,b);});
test('remember explicitly loaded slot even if a different slot was saved later',async()=>{const local=memory(),store=create(local,idb([{id:1,state:make(),updated:100},{id:2,state:make(),updated:200}]));await store.init();store.activate(1);const reload=create(local,idb(store.records()));await reload.init();assert.equal(reload.resume().id,1);});
test('immediate journal survives closing before IndexedDB finishes',async()=>{const local=memory(),state=make(),store=create(local,idb([],{hold:true}));await store.init();E.next(state);const pending=store.save(state,1);const reopen=create(local,idb([]));await reopen.init();assert.deepEqual(reopen.resume().state,state);assert.ok((await pending).local);});
test('legacy localStorage saves remain visible when IndexedDB is newly available',async()=>{const local=memory();local.setItem('muga-fallback',JSON.stringify([{id:3,state:make(),updated:50}]));const store=create(local,idb([]));await store.init();assert.equal(store.resume().id,3);});
test('IDB read/write failures fall back to the journal and report accurate status',async()=>{const local=memory(),store=create(local,idb([],{failRead:true,failWrite:true}));await store.init();const result=await store.save(make(),1);assert.equal(result.ok,true);assert.equal(result.indexedDB,false);const reload=create(local,idb([],{failRead:true}));await reload.init();assert.equal(reload.resume().id,1);});
test('invalid current data recovers previous checkpoint; malformed slots do not hide good ones',async()=>{const s=make(),local=memory(),store=create(local,idb([{id:1,state:{},previous:s,updated:200},{id:2,state:{},updated:300},{id:3,state:s,updated:100}]));await store.init();assert.equal(store.records().length,2);assert.equal(store.resume().id,1);assert.equal(store.resume().recovered,true);assert.deepEqual(store.resume().state,s);});
test('visibility/pagehide checkpoint preserves a pending event without rerolling',async()=>{const local=memory(),s=make(),store=create(local,null);await store.init();s.phase='league';s.round=4;s.event=E.eventById(s,'E11');s.eventSeen.push('E11');s.event.context={source:'第4轮例会',reason:'日常事务'};store.checkpoint(s,1);const again=create(local,null);await again.init();assert.deepEqual(again.resume().state,s);});
test('a failed journal still uses IDB; both storage failures return an error',async()=>{const local={getItem(){throw Error('blocked');},setItem(){throw Error('quota');}};const good=create(local,idb([]));await good.init();assert.ok((await good.save(make(),1)).ok);const bad=create(local,idb([],{failWrite:true}));await bad.init();assert.equal((await bad.save(make(),1)).ok,false);});
test('rapid saves retain final state and previous checkpoint in transaction order',async()=>{const local=memory(),db=idb([]),store=create(local,db),s=make();await store.init();const a=store.save(s,1);E.next(s);const b=store.save(s,1);E.chooseEvent(s,s.event.options.findIndex(o=>!o.fx.cost&&!o.fx.adviser));E.next(s);const c=store.save(s,1);await Promise.all([a,b,c]);const reload=create(local,db);await reload.init();assert.equal(reload.resume().state.windowStep,2);assert.equal(reload.resume().previous.windowStep,1);});
test('newer exit journal uses the last committed state as its recovery point',async()=>{const local=memory(),s=make(),older=cp(s);E.next(s);const committed=cp(s),db=idb([{id:1,state:committed,previous:older,updated:100}]);E.chooseEvent(s,s.event.options.findIndex(o=>!o.fx.cost&&!o.fx.adviser));E.next(s);local.setItem('muga-slot-v2-1',JSON.stringify({id:1,state:s,updated:200}));const reopen=create(local,db);await reopen.init();assert.equal(reopen.resume().state.windowStep,2);assert.equal(reopen.resume().previous.windowStep,1);});
