const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),dist=path.join(root,'dist');
let html=fs.readFileSync(path.join(dist,'index.html'),'utf8');
html=html.replace(/<link rel="manifest"[^>]*>/,'').replace(/<link rel="icon"[^>]*>/,'').replace('<link rel="stylesheet" href="style.css">',()=>'<style>'+fs.readFileSync(path.join(dist,'style.css'),'utf8')+'</style>');
for(const script of ['extra-events.js','operations.js','real-players.js','engine.js','backup.js','storage.js','event-guide.js','app.js'])html=html.replace(`<script src="${script}"></script>`,()=>'<script>'+fs.readFileSync(path.join(dist,script),'utf8').replace(/<\/script/gi,'<\\/script')+'</script>');
fs.writeFileSync(path.join(root,'..','MUGA 可玩版.html'),html);
fs.writeFileSync(path.join(dist,'muga-offline.html'),html);
console.log('Offline artifact created: '+path.join(root,'..','MUGA 可玩版.html'));
