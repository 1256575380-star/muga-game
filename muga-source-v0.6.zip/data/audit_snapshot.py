import json,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=ROOT/'real-roster.json';d=json.loads(p.read_text(encoding='utf-8'))
# Resolve known duplicate/source mixups using cross-checks, never by inventing a second identity.
RESOLVED={
 'espn306033':('espn331','https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season','Hadjam listed for Brighton in official 2026/27 squad; Young Boys roster stale'),
 'espn286120':('espn394','https://theanalyst.com/players/8465/leo-leroy','Opta current profile identifies Preston and August 2026 move from Basel'),
 'espn322209':('espn2994','https://site.api.espn.com/apis/site/v2/sports/soccer/por.1/teams/2994/roster','ESPN defaultTeam on stale Basel entry identifies Braga'),
 'espn136597':('espn2790','https://site.api.espn.com/apis/site/v2/sports/soccer/aut.1/teams/2790/roster','ESPN defaultTeam on stale Basel entry identifies Salzburg'),
 'espn268019':('espn493','https://shakhtar.com/en/news/2026/may/19_news/19_traore/','Shakhtar official contract announcement confirms the 2001-born forward; Salzburg API confused the 2007-born namesake')
}
excluded=[]
original=ROOT/'real-roster.partial.json'
if original.exists():
    for c in json.loads(original.read_text(encoding='utf-8'))['clubs']:
        for row in c['players']:
            r=RESOLVED.get(row['id'])
            if r and r[0]!=c['id']:
                excluded.append({'club':c['id'],'player':row,'reason':r[2],'verificationUrl':r[1]})
for c in d['clubs']:
    kept=[]
    for row in c['players']:
        r=RESOLVED.get(row['id'])
        if r and r[0]!=c['id']:
            if not any(x['club']==c['id'] and x['player']['id']==row['id'] for x in excluded):excluded.append({'club':c['id'],'player':row,'reason':r[2],'verificationUrl':r[1]})
            continue
        if r:row['clubVerificationUrl']=r[1]
        kept.append(row)
    c['players']=kept
ALIASES={
'42250':'汤姆·希顿','130877':'卡尔·达洛','301425':'森内·拉门斯','325550':'德莫特·米',
'157073':'哈里·马奎尔','167127':'卢克·肖','233937':'利桑德罗·马丁内斯','238902':'迪奥戈·达洛特','239349':'马泰斯·德利赫特','239350':'努赛尔·马兹拉维','340206':'莱尼·约罗','356044':'埃登·海文','356940':'哈里·阿马斯','366781':'帕特里克·多古','381055':'丹尼尔·阿默尔','386199':'杰登·卡马森',
'124091':'布鲁诺·费尔南德斯','193297':'尤里·蒂勒曼斯','205081':'杰克·弗莱彻','231167':'梅森·芒特','241468':'曼努埃尔·乌加特','314858':'安德烈·桑托斯','328466':'科比·梅努','338814':'卡洛斯·巴莱巴','393138':'泰勒·弗莱彻',
'230945':'马库斯·拉什福德','259902':'马特乌斯·库尼亚','271170':'布赖恩·姆伯莫','276327':'约书亚·齐尔克泽','289155':'本杰明·谢什科','291630':'阿马德·迪亚洛','358180':'谢伊·莱西','397881':'蒂南·汤普森'}
united=next(c for c in d['clubs'] if c['id']=='espn360')
for row in united['players']:row['nameZh']=ALIASES.get(row['id'][4:])
united['verificationUrl']='https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season'
counts=collections.Counter(row['id'] for c in d['clubs'] for row in c['players'])
assert max(counts.values())==1
assert len(united['preferredIds'])==25
assert len([c for c in d['clubs'] if c['league']])==20
audit={'asOf':d['asOf'],'clubs':len(d['clubs']),'players':sum(len(c['players']) for c in d['clubs']),'englishTopTier':sum(c['league'] for c in d['clubs']),'otherEuropeanClubs':sum(not c['competition'].startswith('eng.') for c in d['clubs']),'missingNationality':sum(not row.get('nationality') for c in d['clubs'] for row in c['players']),'minimumSquad':min(len(c['players']) for c in d['clubs']),'minimumGoalkeepers':min(sum(row['position']=='GK' for row in c['players']) for c in d['clubs']),'excluded':excluded,'notes':['Missing DOB and unsupported positions are omitted during extraction; missing nationality stays null.','NameZh is editorial transliteration, original source name retained.','Salaries, valuations, ratings, potential and current contractual terms are not sourced by this dataset.','Current rosters may include academy fringe players and loan-register nuances; these are not all guaranteed senior registrations.','Dynamo Kyiv not included; Braga supplies the 60th non-English European club.']}
d['audit']={k:v for k,v in audit.items() if k!='excluded'}
p.write_text(json.dumps(d,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
(ROOT/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(d['audit'],ensure_ascii=True))
