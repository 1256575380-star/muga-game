from extract_rosters import fetch,BASE,ROOT
import json,concurrent.futures,datetime,re,sys
sys.stdout.reconfigure(encoding='utf-8')
NAMES={
'349':'伯恩茅斯','359':'阿森纳','362':'阿斯顿维拉','337':'布伦特福德','331':'布莱顿','363':'切尔西','388':'考文垂','384':'水晶宫','368':'埃弗顿','370':'富勒姆','306':'赫尔城','373':'伊普斯维奇','357':'利兹联','364':'利物浦','382':'曼城','360':'曼联','361':'纽卡斯尔','393':'诺丁汉森林','366':'桑德兰','367':'热刺',
'392':'伯明翰','365':'布莱克本','358':'博尔顿','333':'布里斯托城','379':'伯恩利','347':'卡迪夫城','372':'查尔顿','374':'德比郡','314':'林肯城','369':'米德尔斯堡','391':'米尔沃尔','381':'诺维奇','385':'朴茨茅斯','394':'普雷斯顿','334':'女王公园巡游者','398':'谢菲尔德联','376':'南安普顿','336':'斯托克城','318':'斯旺西','395':'沃特福德','383':'西布朗','371':'西汉姆联','380':'狼队','352':'雷克瑟姆',
'86':'皇家马德里','83':'巴塞罗那','132':'拜仁慕尼黑','160':'巴黎圣日耳曼','110':'国际米兰','103':'AC米兰','111':'尤文图斯','114':'那不勒斯','124':'多特蒙德','131':'勒沃库森','1068':'马德里竞技','93':'毕尔巴鄂','1929':'本菲卡','437':'波尔图','2250':'葡萄牙体育','139':'阿贾克斯','148':'埃因霍温','142':'费耶诺德','176':'马赛','167':'里昂','174':'摩纳哥','166':'里尔','104':'罗马','112':'拉齐奥','105':'亚特兰大','109':'佛罗伦萨','89':'皇家社会','102':'比利亚雷亚尔','244':'贝蒂斯','243':'塞维利亚','11420':'莱比锡','125':'法兰克福','134':'斯图加特','126':'弗赖堡','2790':'萨尔茨堡','257':'格拉斯哥流浪者','256':'凯尔特人','570':'布鲁日','441':'安德莱赫特','909':'哥本哈根','432':'加拉塔萨雷','436':'费内巴切','1895':'贝西克塔斯','435':'奥林匹亚科斯','887':'雅典AEK','597':'萨格勒布迪纳摩','2290':'贝尔格莱德红星','494':'布拉格斯拉维亚','433':'布拉格斯巴达','493':'顿涅茨克矿工','2722':'年轻人','989':'巴塞尔','7672':'卢加诺','519':'维也纳快速','3746':'格拉茨风暴','2502':'尼斯','239':'都灵','2950':'美因茨','9812':'赫罗纳','2994':'布拉加','375':'莱斯特城'}
# Swiss domestic endpoints still expose 2025/26. Keep one consistent 2026/27 source season.
for old in ['2722','989','7672']:NAMES.pop(old,None)
NAMES.update({'107':'博洛尼亚','94':'瓦伦西亚','7911':'霍芬海姆'})
index=json.loads((ROOT/'club-index.json').read_text(encoding='utf-8'))
for id,name,league in [('597','Dinamo Zagreb','uefa.europa'),('2290','Red Star Belgrade','uefa.europa.conf'),('494','Slavia Prague','uefa.champions'),('433','Sparta Prague','uefa.europa'),('493','Shakhtar Donetsk','uefa.champions'),('9812','Girona','esp.2'),('375','Leicester City','eng.3')]:
    index.append({'id':id,'name':name,'league':league,'slug':''})
index=[x for x in index if x['id'] in NAMES]
def roster(team):
    url=BASE+team['league']+'/teams/'+team['id']+'/roster'
    raw=fetch(url)
    result={'id':'espn'+team['id'],'espnId':team['id'],'name':NAMES[team['id']],'nameEn':team['name'],'sourceUrl':url,'pageUrl':'https://www.espn.com/soccer/team/squad/_/id/'+team['id'],'competition':team['league'],'league':team['league']=='eng.1','sourceSeason':raw.get('season',{}).get('displayName'),'players':[]}
    for p in raw.get('athletes',[]):
        if not p.get('dateOfBirth') or p.get('position',{}).get('abbreviation') not in ['G','D','M','F']:
            continue
        default=re.search(r'/teams/(\d+)',p.get('defaultTeam',{}).get('$ref',''))
        obj={'id':'espn'+p['id'],'name':p['displayName'],'position':{'G':'GK','D':'DF','M':'MF','F':'FW'}[p['position']['abbreviation']],'dob':p['dateOfBirth'][:10],'nationality':p.get('citizenship'),'jersey':p.get('jersey'),'sourceUrl':next((x['href'] for x in p.get('links',[]) if 'playercard' in x.get('rel',[])),url)}
        if default and default[1]!=team['id']:obj['sourceDefaultTeamId']='espn'+default[1]
        result['players'].append(obj)
    return result
clubs=[];errors=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
    for team,future in zip(index,[pool.submit(roster,t) for t in index]):
        try:
            c=future.result();clubs.append(c)
            print(c['name'],len(c['players']))
            data={'asOf':'2026-11-14','startYear':2026,'sourceName':'ESPN','snapshotSeason':'2026/27','clubs':clubs}
            (ROOT/'real-roster.partial.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
        except Exception as e:errors.append({'team':team,'error':str(e)})
united=next(c for c in clubs if c['id']=='espn360')
reserve=['espn325550','espn356940','espn381055','espn386199','espn205081','espn393138','espn358180','espn397881']
united['preferredIds']=[p['id'] for p in united['players'] if p['id'] not in reserve]
united['reserveIds']=[p['id'] for p in united['players'] if p['id'] in reserve]
data['errors']=errors
(ROOT/'real-roster.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
print('DONE',len(clubs),'clubs',sum(len(c['players']) for c in clubs),'rows','ManU selection',len(united['preferredIds']),'errors',errors)
