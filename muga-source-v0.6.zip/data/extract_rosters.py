"""Snapshot factual player identities from ESPN's public roster endpoints.
No ratings, contracts, valuations, images or editorial content are copied.
"""
import concurrent.futures, json, re, time, unicodedata, urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE='https://site.api.espn.com/apis/site/v2/sports/soccer/'
LEAGUES=['eng.1','eng.2','esp.1','ger.1','ita.1','fra.1','por.1','ned.1','aut.1','sco.1','bel.1','den.1','tur.1','gre.1','cro.1','srb.1','cze.1','ukr.1','sui.1']
def fetch(url):
    for attempt in range(3):
        try:
            request=urllib.request.Request(url,headers={'User-Agent':'MUGA factual roster snapshot (no media)'})
            with urllib.request.urlopen(request,timeout=30) as r:return json.load(r)
        except Exception:
            if attempt==2:raise
            time.sleep(1+attempt)
def index_league(code):
    raw=fetch(BASE+code+'/teams?limit=100')
    teams=raw['sports'][0]['leagues'][0]['teams']
    return [{'id':x['team']['id'],'name':x['team']['displayName'],'league':code,'slug':x['team']['slug']} for x in teams]
def main():
    ROOT.mkdir(exist_ok=True,parents=True)
    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        for code, fut in zip(LEAGUES,[pool.submit(index_league,c) for c in LEAGUES]):
            try:results.extend(fut.result())
            except Exception as e:print(code,str(e))
    (ROOT/'club-index.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Indexed',len(results),'clubs')
if __name__=='__main__':main()
